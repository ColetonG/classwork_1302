package prob2;

public interface Teleporter {
	public String teleport(String dest);
}
