package prob1;

public class ClassicYellowCake extends Cake{
	protected String liquid;
	protected String oil;
	protected String eggs;
	

	public ClassicYellowCake(String cakeMix){
		super(cakeMix);
	}

	@Override
	public String getLiquid() {
		return "1 cup water";
	}


	@Override
	public String getOil() {
		return "1/3 cup vetable oil";
	}


	@Override
	public String getEggs() {
		return "3 large eggs";
	}
}
