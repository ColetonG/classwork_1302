package prob1;

public class HighAltitudeClassicYellowCake extends ClassicYellowCake {
	
	public HighAltitudeClassicYellowCake(String cakeMix) {
		super(cakeMix);
	}
	
	@Override
	public String getCakeMix() {
		String newMix = super.getCakeMix() + " + 2 tbs flour, ";
		return newMix;
	}
	
	@Override 
	public String bake() {
		return "Bake at 375 degrees F 26 minutes";
	}	
}
