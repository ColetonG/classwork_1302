package prob4;

public class EmployeeTest {
	public static void main(String[] arg) {
		String name = "Xavier";
		HourlyEmployee e = new HourlyEmployee(name);
		System.out.println(e);
	}
}
